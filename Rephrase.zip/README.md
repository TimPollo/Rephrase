# Rephrase

Rephrase liest ein kopiertes Foto im Browser und kürzt typische englische Auswahlaufgaben. Aus „Please select all squares containing a duck to confirm your account“ wird **Select all ducks**. Wichtige Merkmale bleiben erhalten, etwa in **Select all white tigers**. Bei unbekannten Formulierungen zeigt Rephrase den erkannten Text.

## Auf GitHub veröffentlichen

1. Entpacke die ZIP-Datei auf dem Mac.
2. Erstelle auf GitHub ein neues Repository namens `rephrase`. Für GitHub Free wähle **Public**.
3. Öffne im neuen Repository **uploading an existing file** oder **Add file → Upload files**. Ziehe den gesamten Inhalt des entpackten Ordners in das Upload-Feld, einschließlich des Ordners `assets`. Nach dem Hochladen muss `index.html` direkt auf der obersten Ebene neben `assets` liegen.
4. Klicke auf **Commit changes**, um die Dateien im Branch `main` zu speichern.
5. Öffne **Settings → Pages**. Wähle **Deploy from a branch**, dann **main** und **/(root)**. Klicke auf **Save**.
6. Sobald GitHub die Seite veröffentlicht hat, öffne **Visit site** in **Settings → Pages**. Bei einem Repository namens `rephrase` lautet die Adresse normalerweise `https://DEIN-GITHUB-NAME.github.io/rephrase/`.

Der Ordner enthält alle benötigten Dateien zur direkten Veröffentlichung. Der Build-Schritt entfällt. [GitHub-Dokumentation zu Pages](https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site)

## Auf dem iPhone verwenden

Öffne die veröffentlichte Adresse in Safari. Über **Teilen → Zu Home-Bildschirm hinzufügen** kannst du **Als Web-App öffnen** aktivieren und **Hinzufügen** wählen. [Apple-Anleitung](https://support.apple.com/de-de/guide/iphone/iphea86e5236/ios)

Kopiere ein Foto und tippe in Rephrase auf **Bild einsetzen**. Bestätige bei Bedarf die Einfügeabfrage von Safari. Alternativ öffnet **Foto auswählen** die Bildauswahl. Auf einem Computer kannst du auch ein kopiertes Bild mit dem üblichen Tastenkürzel einsetzen.

Beim Öffnen und zur ersten Erkennung lädt der Browser die Programm- und Sprachdateien von deiner GitHub-Pages-Adresse. Die Bildauswertung läuft auf dem Gerät. Die Kurzfassung erscheint als Text. Wie gut sie gelingt, hängt von der Lesbarkeit und vom Wortlaut der Aufgabe ab.

## Inhalt des Repositorys

| Datei oder Ordner | Zweck |
| --- | --- |
| `index.html` und `style.css` | Bedienoberfläche |
| `app.js` | Bilder einsetzen oder auswählen und Text erkennen |
| `phrase.js` | Englische Auswahlaufgaben kürzen |
| `manifest.webmanifest` | Name und Startverhalten auf dem Home-Bildschirm |
| `assets/` | App-Symbole, OCR-Programm, englische Sprachdaten, Pluralregeln und Lizenztexte |
| `README.md` | Diese Anleitung |

Die Texterkennung verwendet [Tesseract.js](https://github.com/naptha/tesseract.js), den [WebAssembly-Kern](https://github.com/naptha/tesseract.js-core) und [englische Sprachdaten](https://github.com/naptha/tessdata). Die englische Pluralbildung nutzt [pluralize](https://github.com/plurals/pluralize).
