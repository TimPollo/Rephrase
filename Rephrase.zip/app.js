"use strict";
const paste = document.querySelector("#paste");
const choose = document.querySelector("#choose");
const file = document.querySelector("#file");
const heading = document.querySelector("#heading");
const intro = document.querySelector("#intro");
const statusLine = document.querySelector("#status");
const result = document.querySelector("#result");
const sheet = document.querySelector(".sheet");
const ocrPath = new URL("./assets/ocr/", document.baseURI).href;
let busy = false;

function clearResult() {
  sheet.classList.remove("has-result");
  heading.textContent = "Welche Aufgabe steht im Bild?";
  result.textContent = "";
  result.hidden = true;
  intro.hidden = false;
}

async function scan(blob) {
  if (!blob || busy) return;
  busy = true;
  paste.disabled = choose.disabled = true;
  clearResult();
  statusLine.textContent = "Texterkennung wird geladen …";
  let worker;
  const imageURL = URL.createObjectURL(blob);
  try {
    const image = new Image();
    image.src = imageURL;
    await image.decode();
    // Limit memory on small phones; upscale small print for recognition.
    const scale = Math.min(2, 2200 / Math.max(image.width, image.height));
    const canvas = document.createElement("canvas");
    canvas.width = Math.max(1, Math.round(image.width * scale));
    canvas.height = Math.max(1, Math.round(image.height * scale));
    const context = canvas.getContext("2d");
    context.fillStyle = "white";
    context.fillRect(0, 0, canvas.width, canvas.height);
    context.drawImage(image, 0, 0, canvas.width, canvas.height);
    worker = await Tesseract.createWorker("eng", Tesseract.OEM.LSTM_ONLY, {
      workerPath: ocrPath + "worker.min.js",
      corePath: ocrPath,
      langPath: ocrPath,
      workerBlobURL: false,
      logger: event => {
        if (event.status === "recognizing text") {
          statusLine.textContent = "Text wird gelesen … " + Math.round(event.progress * 100) + " %";
        }
      }
    });
    await worker.setParameters({ tessedit_pageseg_mode: Tesseract.PSM.AUTO });
    const {data} = await worker.recognize(canvas, {}, {text:true, blocks:true});
    const reading = readInstruction(data.blocks || [], data.text);
    if (reading.text) {
      heading.textContent = reading.short ? "Deine Kurzfassung" : "Erkannter Text";
      sheet.classList.add("has-result");
      intro.hidden = true;
      result.textContent = reading.text;
      result.hidden = false;
      statusLine.textContent = reading.short ? "" : "Für diesen Wortlaut wurde keine eindeutige Kurzform gefunden.";
      result.setAttribute("tabindex", "-1");
      result.focus({preventScroll:true});
    } else {
      statusLine.textContent = "Kein Text erkannt. Versuche einen schärferen Ausschnitt der Frage.";
    }
  } catch (error) {
    console.error("Rephrase", error.name);
    statusLine.textContent = "Das Bild konnte nicht gelesen werden. Prüfe die Verbindung beim Laden oder wähle einen Screenshot als PNG oder JPEG.";
  } finally {
    URL.revokeObjectURL(imageURL);
    try { if (worker) await worker.terminate(); }
    finally { busy = false; paste.disabled = choose.disabled = false; }
  }
}

choose.addEventListener("click", () => file.click());
file.addEventListener("change", () => {
  const chosen = file.files[0];
  file.value = "";
  scan(chosen);
});

paste.addEventListener("click", async () => {
  if (busy) return;
  try {
    const items = await navigator.clipboard.read();
    for (const item of items) {
      const type = item.types.find(type => type.startsWith("image/"));
      if (type) { await scan(await item.getType(type)); return; }
    }
    statusLine.textContent = "Kein Bild in der Zwischenablage. Kopiere das Foto selbst oder tippe auf „Foto auswählen“.";
  } catch {
    statusLine.textContent = "Erlaube Safari das Einsetzen oder tippe auf „Foto auswählen“.";
  }
});
document.addEventListener("paste", event => {
  const item = Array.from(event.clipboardData?.items || []).find(item => item.type.startsWith("image/"));
  if (item) { event.preventDefault(); scan(item.getAsFile()); }
});
