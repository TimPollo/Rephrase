// The target phrase comes only from the written instruction.
function shortenInstruction(input) {
  const text = input.trim().replace(/\s+/g, " ")
    .replace(/\s+(?:in order )?to (?:confirm|verify) (?:your (?:identity|account)|(?:that )?you(?: are|'re) (?:a )?human)[.!:?]*$/i, "")
    .replace(/[.!:?]+$/, "").trim();
  const command = text.match(/^(?:please |can you |could you )?(?:select|choose|pick|tap(?: on)?|click(?: on)?|mark|find|identify) (all(?: of)?(?: the)?|every|each) (.+)$/i);
  const question = text.match(/^which (?:of (?:these|the following) )?(?:squares?|tiles?|images?|pictures?|photos?|boxes?) (?:contain|show|feature|have) (.+)$/i);
  if (!command && !question) return null;
  let target = command ? command[2] : question[1];
  const frame = target.match(/^(?:squares?|tiles?|images?|pictures?|photos?|boxes?) (?:with|of|containing|showing|featuring|(?:which|that) (?:contains?|shows?|features?|have|has)) (.+)$/i);
  if (frame) target = frame[1];
  const needsPlural = /^(?:a|an) /i.test(target) || (command && !frame && /^(?:each|every)$/i.test(command[1]));
  target = target.replace(/^(?:an? |the )/i, "");
  if (target.length > 110 || !/^[a-z][a-z ’'-]*$/i.test(target) ||
      /\b(?:unless|except|but|then|only if|confirm|verify|please)\b/i.test(target)) return null;
  if (needsPlural) {
    const noun = target.match(/^(.+?)(\s+(?:with|without|in|on|under|beside|wearing|that|which|next to)\b.*)?$/i);
    if (!noun || /\b(?:and|or)\b/i.test(noun[1])) return null;
    const head = noun[1].replace(/[a-z]+$/i, word => pluralize.plural(word));
    target = head + (noun[2] || "");
  }
  return "Select all " + target;
}

function readInstruction(blocks, rawText) {
  const lines = blocks.flatMap(block => block.paragraphs.flatMap(para => para.lines))
    .filter(line => line.text.trim()).sort((a, b) => a.bbox.y0 - b.bbox.y0);
  const groups = [];
  let previous;
  for (const {text, bbox} of lines) {
    const gap = previous ? bbox.y0 - previous.y1 : Infinity;
    const height = bbox.y1 - bbox.y0;
    if (!previous || gap > 1.4 * Math.max(height, previous.y1 - previous.y0)) groups.push([]);
    groups[groups.length - 1].push(text.trim());
    previous = bbox;
  }
  for (const group of groups) {
    for (let start = 0; start < group.length; start++) {
      const phrase = shortenInstruction(group.slice(start).join(" "));
      if (phrase) return { text: phrase, short: true };
    }
  }
  const text = rawText.trim();
  return { text, short: false };
}
